
// import React from "react";
// import AgentTypePage from "./components/AgentTypePage";
// import TrainDoc from "./components/train_doc";
// import Step2 from "./components/Step2";
// import Step3 from "./components/Step3";
// import ReviewAgentPage from "./components/ReviewAgentPage";
// import ChatBot from "./components/ChatBot";
// import SignIn from "./components/SignIn";
// import ContactsDashboard from "./components/ContactsDashboard";
// import DashboardLayout from "./components/layout/DashboardLayout";

// function isLoggedIn() {
//   return Boolean(localStorage.getItem("auth_token"));
// }

// export default function App() {
//   const path = window.location.pathname;

//   if (path.startsWith("/chat/") || path.startsWith("/chat_")) {
//     return <ChatBot />;
//   }

//   if (!isLoggedIn()) {
//     return <SignIn />;
//   }

//   if (path === "/contacts") {
//     return <ContactsDashboard />;
//   }

//   if (path === "/" || path === "/dashboard" || path === "/agent-type") {
//     return (
//       <DashboardLayout title="Chat Agents">
//         <AgentTypePage />
//       </DashboardLayout>
//     );
//   }

//   if (path === "/train") {
//     return (
//       <DashboardLayout title="Chat Agents">
//         <TrainDoc />
//       </DashboardLayout>
//     );
//   }

//   if (path === "/step2") {
//     return (
//       <DashboardLayout title="Chat Agents">
//         <Step2 />
//       </DashboardLayout>
//     );
//   }

//   if (path === "/step3") {
//     return (
//       <DashboardLayout title="Chat Agents">
//         <Step3 />
//       </DashboardLayout>
//     );
//   }

//   if (path === "/review-agent") {
//     return (
//       <DashboardLayout title="Chat Agents">
//         <ReviewAgentPage />
//       </DashboardLayout>
//     );
//   }

//   return (
//     <DashboardLayout title="Chat Agents">
//       <AgentTypePage />
//     </DashboardLayout>
//   );
// } 


import React from "react";
import AgentTypePage from "./components/AgentTypePage";
import TrainDoc from "./components/train_doc";
import Step2 from "./components/Step2";
import Step3 from "./components/Step3";
import ReviewAgentPage from "./components/ReviewAgentPage";
import ChatBot from "./components/ChatBot";
import SignIn from "./components/SignIn";
import ContactsDashboard from "./components/ContactsDashboard";
import DashboardLayout from "./components/layout/DashboardLayout";

function isLoggedIn() {
  return Boolean(localStorage.getItem("auth_token"));
}

export default function App() {
  const path = window.location.pathname;

  if (path.startsWith("/chat/") || path.startsWith("/chat_")) {
    return <ChatBot />;
  }

  if (!isLoggedIn()) {
    return <SignIn />;
  }

  if (path === "/contacts") {
    return <ContactsDashboard />;
  }

  if (path === "/" || path === "/dashboard" || path === "/agent-type") {
    return (
      <DashboardLayout title="Chat Agents">
        <AgentTypePage />
      </DashboardLayout>
    );
  }

  if (path === "/train") {
    return (
      <DashboardLayout title="Chat Agents">
        <TrainDoc />
      </DashboardLayout>
    );
  }

  if (path === "/step2") {
    return (
      <DashboardLayout title="Chat Agents">
        <Step2 />
      </DashboardLayout>
    );
  }

  if (path === "/step3") {
    return (
      <DashboardLayout title="Chat Agents">
        <Step3 />
      </DashboardLayout>
    );
  }

  if (path === "/review-agent") {
    return (
      <DashboardLayout title="Chat Agents">
        <ReviewAgentPage />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Chat Agents">
      <AgentTypePage />
    </DashboardLayout>
  );
}