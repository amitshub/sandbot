import React, { useState } from "react";
import { Copy, Hash, KeyRound, Link, Plus, Save, ShieldCheck } from "lucide-react";
import AgentSteps from "./training/AgentSteps";

function Field({ label, placeholder, type = "text" }) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span>
      <input
        type={type}
        placeholder={placeholder}
        className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
      />
    </label>
  );
}

export default function Step3() {
  const [verifyToken] = useState("agentive_verify_token_123");
  const callbackUrl = "https://app.agentive.co.in/webhooks/whatsapp";

  const copyText = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // clipboard can fail on non-https/local browsers; keep UI safe
    }
  };

  return (
    <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
      <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
        <div className="flex items-center justify-between">
          <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
            <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
          </button>
          <p className="text-xs font-semibold text-slate-400">Step 5 of 5</p>
          
        </div>
      </div>

      <AgentSteps current={5} />

      <section className="mx-auto max-w-5xl px-5 py-10">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-100 text-purple-600">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-slate-950">Connect WhatsApp in 5 minutes</h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Get your API credentials from Meta, paste them below, and your AI agent goes live on WhatsApp.
              </p>
            </div>
          </div>

          <div className="mt-7 grid gap-5">
            {[
              ["1", "Create a Meta Business app", "Visit developers.facebook.com and create a new app. Pick Business as the type."],
              ["2", "Add WhatsApp to your app", "In your app dashboard, click Add product and pick WhatsApp."],
              ["3", "Copy your API credentials", "You will need permanent access token, phone number ID, and business account ID."],
              ["4", "Paste them below and connect", "We verify your credentials with Meta before saving."],
              ["5", "Set the webhook in Meta", "Use the callback URL and verify token, then subscribe to messages."],
            ].map(([no, title, text]) => (
              <div key={no} className="flex gap-4">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-purple-500 text-sm font-bold text-white">{no}</div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">{title}</h3>
                  <p className="mt-1 text-sm leading-6 text-slate-500">{text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-100 text-purple-600">
                <Link className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-slate-950">Webhook configuration</h3>
            </div>

            <div className="space-y-4">
              <div>
                <span className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-500">Callback URL</span>
                <div className="flex gap-2">
                  <input readOnly value={callbackUrl} className="h-12 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-600" />
                  <button onClick={() => copyText(callbackUrl)} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-purple-600">
                    <Copy className="h-4 w-4" /> Copy
                  </button>
                </div>
              </div>

              <div>
                <span className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-500">Verify Token</span>
                <input readOnly value={verifyToken} className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-600" />
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-100 text-purple-600">
                <KeyRound className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-slate-950">Enter your API credentials</h3>
            </div>

            <div className="space-y-4">
              <Field label="Permanent Access Token" placeholder="Paste Meta access token" type="password" />
              <Field label="Phone Number ID" placeholder="Enter phone number ID" />
              <Field label="Business Account ID" placeholder="Enter business account ID" />
              <Field label="Verify Token" placeholder="Enter verify token" />
            </div>
          </div>
        </div>

        <div className="mt-8 flex items-center justify-between">
          <button
            onClick={() => (window.location.href = "/step2")}
            className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
          >
            ← Back
          </button>
          <button className="inline-flex items-center gap-2 rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600">
            <Save className="h-4 w-4" /> Save & Finish
          </button>
        </div>
      </section>
    </div>
  );
}
