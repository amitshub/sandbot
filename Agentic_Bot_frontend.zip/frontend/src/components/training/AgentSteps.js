import React from "react";
import { Check, Globe2, Palette, Rocket, Settings } from "lucide-react";

const steps = [
  { label: "Agent Type", icon: Check, path: "/agent-type" },
  { label: "Your Business", icon: Globe2, path: "/train" },
  { label: "Training", icon: Rocket, path: "/step2" },
  { label: "Customize", icon: Palette, path: "/review-agent" },
  { label: "Connect", icon: Settings, path: "/step3" },
];

export default function AgentSteps({ current = 1 }) {
  const progressWidth =
    current <= 1
      ? "0%"
      : current === 2
      ? "25%"
      : current === 3
      ? "50%"
      : current === 4
      ? "75%"
      : "100%";

  return (
    <div className="border-b border-slate-100 bg-white">
      <div className="mx-auto max-w-[860px] px-2 py-7">
        <div className="relative flex items-start justify-between">
          <div className="absolute left-[8%] right-[8%] top-[24px] h-[4px] rounded-full bg-slate-200" />

          <div
            className="absolute left-[8%] top-[24px] h-[4px] rounded-full bg-purple-500 transition-all duration-300"
            style={{ width: progressWidth }}
          />

          {steps.map((step, index) => {
            const StepIcon = step.icon;
            const number = index + 1;
            const done = number < current;
            const active = number === current;

            return (
              <button
                key={step.label}
                type="button"
                onClick={() => (window.location.href = step.path)}
                className="relative z-10 flex w-28 flex-col items-center bg-transparent"
              >
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-full border text-sm shadow-sm ${
                    done || active
                      ? "border-purple-500 bg-purple-500 text-white"
                      : "border-slate-300 bg-white text-slate-400"
                  }`}
                >
                  <StepIcon className="h-5 w-5" />
                </div>

                <p
                  className={`mt-3 text-center text-[12px] font-semibold ${
                    active ? "text-purple-600" : "text-slate-500"
                  }`}
                >
                  {step.label}
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}