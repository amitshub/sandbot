import React from "react";
import { Bot, CalendarDays, MessageSquare, Phone, TrendingUp, Users } from "lucide-react";
import DashboardLayout from "./layout/DashboardLayout";

const contacts = [
  { name: "Test", phone: "989898989889", firstSeen: "1m ago", messages: 5, lastSeen: "just now" },
  { name: "Test", phone: "8954174763", firstSeen: "21m ago", messages: 14, lastSeen: "19m ago" },
];

function StatCard({ label, value, icon: Icon, tone = "purple" }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[13px] font-bold uppercase tracking-wider text-slate-500">{label}</p>
          <p className="mt-4 text-[30px] font-extrabold leading-none text-slate-950">{value}</p>
        </div>
        <div className={`rounded-xl p-2 ${tone === "green" ? "bg-emerald-50 text-emerald-600" : tone === "blue" ? "bg-blue-50 text-blue-600" : "bg-purple-50 text-purple-600"}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

export default function ContactsDashboard() {
  return (
    <DashboardLayout title="Dashboard">
      <div className="mx-auto max-w-[1540px]">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <h2 className="text-[30px] font-extrabold tracking-tight text-slate-950">Contacts</h2>
            <p className="mt-2 text-[17px] text-slate-500">
              Every customer who's spoken to your AI agents — unified across web and WhatsApp.
            </p>
          </div>
          <button className="inline-flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 shadow-sm">
            <CalendarDays className="h-5 w-5 text-slate-400" /> Last 30 Days
          </button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <StatCard label="New Today" value="2" icon={Bot} />
          <StatCard label="New Yesterday" value="0" icon={CalendarDays} tone="blue" />
          <StatCard label="Last 7 Days" value="2" icon={TrendingUp} tone="green" />
          <StatCard label="Total Contacts" value="2" icon={Users} />
        </div>

        <div className="mt-7 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-3 xl:flex-row">
            <input
              className="h-12 flex-1 rounded-xl border border-slate-300 px-6 text-[18px] outline-none placeholder:text-slate-400 focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
              placeholder="Search by name, email, or phone..."
            />
            <select className="h-12 rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 outline-none">
              <option>All AI agents</option>
            </select>
            <select className="h-12 rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 outline-none">
              <option>All channels</option>
            </select>
          </div>
        </div>

        <div className="mt-7 rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
          <h3 className="mb-6 text-[18px] font-bold text-slate-950">2 contacts</h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-left">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-[13px] font-bold uppercase tracking-wider text-slate-500">
                  <th className="px-5 py-4">Name</th>
                  <th className="px-5 py-4">Contact</th>
                  <th className="px-5 py-4">Channels</th>
                  <th className="px-5 py-4">Conversations</th>
                  <th className="px-5 py-4">Open Tickets</th>
                  <th className="px-5 py-4 text-right">Last Seen</th>
                </tr>
              </thead>
              <tbody>
                {contacts.map((contact, index) => (
                  <tr key={`${contact.phone}-${index}`} className="border-b border-slate-100 text-sm last:border-0">
                    <td className="px-5 py-5">
                      <p className="text-[17px] font-bold text-slate-900">{contact.name}</p>
                      <p className="mt-1 text-sm text-slate-500">First seen {contact.firstSeen}</p>
                    </td>
                    <td className="px-5 py-5 text-slate-600">
                      <span className="inline-flex items-center gap-2">
                        <Phone className="h-4 w-4 text-slate-400" /> {contact.phone}
                      </span>
                    </td>
                    <td className="px-5 py-5">
                      <span className="inline-flex items-center rounded-lg bg-blue-50 px-3 py-1 text-xs font-bold text-blue-600">Web</span>
                    </td>
                    <td className="px-5 py-5 text-center">
                      <div className="inline-flex flex-col items-center text-slate-600">
                        <span className="inline-flex items-center gap-1 text-[16px]"><MessageSquare className="h-4 w-4" /> 1</span>
                        <span className="mt-1 text-xs text-slate-400">{contact.messages} msgs</span>
                      </div>
                    </td>
                    <td className="px-5 py-5 text-center text-slate-300">—</td>
                    <td className="px-5 py-5 text-right text-sm font-medium text-slate-500">{contact.lastSeen}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
