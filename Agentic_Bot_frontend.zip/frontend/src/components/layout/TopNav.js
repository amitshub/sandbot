import React from "react";
import { ChevronDown } from "lucide-react";

function getUserName() {
  return localStorage.getItem("user_name") || "Yogesh Kumar";
}

export default function TopNav({ title = "Dashboard" }) {
  const userName = getUserName();
  const initials = userName
    .split(" ")
    .map((word) => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-slate-200 bg-white px-6 lg:px-8">
      <h1 className="text-[20px] font-bold tracking-tight text-slate-950">{title}</h1>
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-600 text-sm font-bold text-white">
          {initials || "YK"}
        </div>
        <span className="hidden text-sm font-semibold text-slate-700 sm:inline">{userName}</span>
        <ChevronDown className="h-4 w-4 text-slate-400" />
      </div>
    </header>
  );
}
