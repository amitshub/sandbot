import React from "react";
import Sidebar from "./Sidebar";
import TopNav from "./TopNav";

export default function DashboardLayout({ title = "Dashboard", children }) {
  return (
    <div className="min-h-screen bg-[#f6f8fc] font-sans text-slate-950">
      <Sidebar />
      <div className="min-h-screen lg:pl-[260px]">
        <TopNav title={title} />
        <main>{children}</main>
      </div>
      <button className="fixed bottom-5 right-5 rounded-full bg-slate-950 px-5 py-3 text-sm font-bold text-white shadow-xl">
        Feedback
      </button>
    </div>
  );
}
