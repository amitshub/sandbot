import React from "react";
import {
  Bot,
  Briefcase,
  CreditCard,
  Grid3X3,
  LogOut,
  MessageSquare,
  Phone,
  Settings,
  Users,
} from "lucide-react";

const navItems = [
  { label: "Overview", icon: Grid3X3, path: "/dashboard" },
  { label: "Chat Agents", icon: MessageSquare, path: "/agent-type" },
  { label: "Contacts", icon: Users, path: "/contacts" },
];

const exploreItems = [
  { label: "Voice Agents", icon: Phone, path: "#" },
  { label: "Cloud Telephony", icon: Phone, path: "#" },
  { label: "CRM", icon: Briefcase, path: "#" },
];

const accountItems = [
  { label: "Team", icon: Users, path: "#" },
  { label: "Billing", icon: CreditCard, path: "#" },
  { label: "Settings", icon: Settings, path: "#" },
];

function getUserName() {
  return localStorage.getItem("user_name") || "Yogesh Kumar";
}

function NavLink({ item, active }) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => {
        if (item.path && item.path !== "#") window.location.href = item.path;
      }}
      className={`flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left text-[14px] font-medium transition ${
        active ? "bg-[#2b1b5f] text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"
      }`}
    >
      <Icon className="h-5 w-5" />
      <span>{item.label}</span>
    </button>
  );
}

function Section({ title, items, activePath }) {
  return (
    <div className="mt-7">
      <p className="mb-3 px-4 text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">{title}</p>
      <div className="space-y-1">
        {items.map((item) => (
          <NavLink key={item.label} item={item} active={activePath === item.path || (item.path === "/agent-type" && ["/train", "/step2", "/step3"].includes(activePath))} />
        ))}
      </div>
    </div>
  );
}

export default function Sidebar() {
  const activePath = window.location.pathname;
  const userName = getUserName();
  const initials = userName
    .split(" ")
    .map((word) => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const logout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("tenant_slug");
    localStorage.removeItem("tenant_id");
    localStorage.removeItem("user_email");
    localStorage.removeItem("user_name");
    window.location.href = "/";
  };

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[260px] flex-col bg-[#0f172a] text-white lg:flex">
      <div className="flex h-[72px] items-center gap-3 px-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600">
          <Bot className="h-5 w-5" />
        </div>
        <div className="text-[20px] font-extrabold tracking-tight">Agentive</div>
      </div>

      <nav className="flex-1 px-3 pt-2">
        <Section title="Workspace" items={navItems} activePath={activePath} />
        <Section title="Explore More" items={exploreItems} activePath={activePath} />
        <Section title="Account" items={accountItems} activePath={activePath} />
      </nav>

      <div className="border-t border-white/10 p-5">
        <div className="flex items-center justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-purple-600 text-sm font-bold">
              {initials || "YK"}
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-white">{userName}</p>
              <p className="text-xs text-slate-500">Member</p>
            </div>
          </div>
          <button type="button" onClick={logout} className="rounded-lg p-2 text-slate-500 hover:bg-white/5 hover:text-white" title="Logout">
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>
    </aside>
  );
}
