// import React, { useMemo, useState } from "react";
// import { Loader2, Lock, Mail, Sparkles } from "lucide-react";

// const API_BASE_URL =
//   process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

// function getTenantSlug() {
//   const path = window.location.pathname;

//   // For URL like: /client/demoapp
//   const clientMatch = path.match(/\/client\/([^/]+)/);
//   if (clientMatch?.[1]) return clientMatch[1];

//   // For subdomain like: demoapp.sandlus.in
//   const host = window.location.hostname;

//   if (host.includes("demoapp")) return "demoapp";
//   if (host.includes("message")) return "message";
//   if (host.includes("futuretechsys")) return "futuretechsys";

//   return localStorage.getItem("tenant_slug") || "demoapp";
// }

// export default function SignIn() {
//   const tenantSlug = useMemo(() => getTenantSlug(), []);

//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const [error, setError] = useState("");
//   const [isLoading, setIsLoading] = useState(false);

//   const canSubmit = email.trim() && password.trim() && !isLoading;

//   const handleLogin = async () => {
//     setError("");

//     if (!email.trim() || !password.trim()) {
//       setError("Please enter email and password.");
//       return;
//     }

//     try {
//       setIsLoading(true);

//       const response = await fetch(`${API_BASE_URL}/auth/login`, {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           tenant_slug: tenantSlug,
//           email: email.trim(),
//           password: password,
//         }),
//       });

//       const result = await response.json().catch(() => null);

//       if (!response.ok) {
//         throw new Error(result?.detail || "Login failed.");
//       }

//       localStorage.setItem("auth_token", result.token);
//       localStorage.setItem("tenant_slug", result.tenant.slug);
//       localStorage.setItem("tenant_id", String(result.tenant.id));
//       localStorage.setItem("user_email", result.user.email);
//       localStorage.setItem("user_name", result.user.name || "");

//       window.location.href = "/train";
//     } catch (err) {
//       setError(err.message || "Something went wrong.");
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const onKeyDown = (e) => {
//     if (e.key === "Enter") {
//       handleLogin();
//     }
//   };

//   return (
//     <div className="min-h-screen bg-slate-100 flex items-center justify-center px-4">
//       <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
//         <div className="text-center">
//           <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-purple-100">
//             <Sparkles className="h-8 w-8 text-purple-600" />
//           </div>

//           <h1 className="text-2xl font-extrabold text-slate-900">
//             Sign in to AI Agent
//           </h1>

//           <p className="mt-2 text-sm text-slate-500">
//             Tenant:{" "}
//             <span className="font-semibold text-purple-600">
//               {tenantSlug}
//             </span>
//           </p>
//         </div>

//         <div className="mt-8 space-y-4">
//           <label className="block">
//             <span className="mb-2 block text-sm font-semibold text-slate-700">
//               Email
//             </span>

//             <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
//               <Mail className="mr-3 h-5 w-5 text-slate-400" />
//               <input
//                 type="email"
//                 value={email}
//                 onChange={(e) => setEmail(e.target.value)}
//                 onKeyDown={onKeyDown}
//                 placeholder="you@company.com"
//                 className="w-full bg-transparent outline-none"
//               />
//             </div>
//           </label>

//           <label className="block">
//             <span className="mb-2 block text-sm font-semibold text-slate-700">
//               Password
//             </span>

//             <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
//               <Lock className="mr-3 h-5 w-5 text-slate-400" />
//               <input
//                 type="password"
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//                 onKeyDown={onKeyDown}
//                 placeholder="Enter password"
//                 className="w-full bg-transparent outline-none"
//               />
//             </div>
//           </label>

//           {error && (
//             <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
//               {error}
//             </div>
//           )}

//           <button
//             type="button"
//             onClick={handleLogin}
//             disabled={!canSubmit}
//             className="flex w-full items-center justify-center gap-2 rounded-xl bg-purple-600 px-5 py-3 font-bold text-white shadow-sm hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-60"
//           >
//             {isLoading ? (
//               <>
//                 <Loader2 className="h-5 w-5 animate-spin" />
//                 Signing in...
//               </>
//             ) : (
//               "Sign In"
//             )}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// } 

import React, { useState } from "react";
import { Loader2, Lock, Mail, Sparkles } from "lucide-react";

const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const canSubmit = email.trim() && password.trim() && !isLoading;

  const handleLogin = async () => {
    setError("");

    if (!email.trim() || !password.trim()) {
      setError("Please enter email and password.");
      return;
    }

    try {
      setIsLoading(true);

      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim(),
          password: password,
        }),
      });

      const result = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(result?.detail || "Login failed.");
      }

      localStorage.setItem("auth_token", result.token);
      localStorage.setItem("tenant_slug", result.tenant.slug);
      localStorage.setItem("tenant_id", String(result.tenant.id));
      localStorage.setItem("user_email", result.user.email);
      localStorage.setItem("user_name", result.user.name || "");

      window.location.href = "/train";
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setIsLoading(false);
    }
  };

  const onKeyDown = (e) => {
    if (e.key === "Enter") {
      handleLogin();
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
        <div className="text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-purple-100">
            <Sparkles className="h-8 w-8 text-purple-600" />
          </div>

          <h1 className="text-2xl font-extrabold text-slate-900">
            Sign in to AI Agent
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Login with your registered company email.
          </p>
        </div>

        <div className="mt-8 space-y-4">
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-700">
              Email
            </span>

            <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
              <Mail className="mr-3 h-5 w-5 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder="you@company.com"
                className="w-full bg-transparent outline-none"
              />
            </div>
          </label>

          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-700">
              Password
            </span>

            <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
              <Lock className="mr-3 h-5 w-5 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder="Enter password"
                className="w-full bg-transparent outline-none"
              />
            </div>
          </label>

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          )}

          <button
            type="button"
            onClick={handleLogin}
            disabled={!canSubmit}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-purple-600 px-5 py-3 font-bold text-white shadow-sm hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Signing in...
              </>
            ) : (
              "Sign In"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}