// import React from "react";
// import { BookOpen, CheckCircle2, Loader2, MessageSquare, Plus, Search } from "lucide-react";
// import AgentSteps from "./training/AgentSteps";

// const trainingSteps = [
//   { title: "Scanning your website", status: "done", icon: CheckCircle2 },
//   { title: "Analyzing your business", status: "done", icon: CheckCircle2 },
//   { title: "Discovering FAQs & content ...", status: "active", icon: Loader2 },
//   { title: "Building knowledge base", status: "pending", icon: BookOpen },
//   { title: "Generating chat experience", status: "pending", icon: MessageSquare },
// ];

// export default function Step2() {
//   const websiteUrl = localStorage.getItem("last_training_url") || "https://www.sonixyhindustries.in/";

//   return (
//     <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
//       <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
//         <div className="flex items-center justify-between">
//           <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
//             <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
//           </button>
//           <p className="text-xs font-semibold text-slate-400">Step 3 of 4</p>
//         </div>
//       </div>

//       <AgentSteps current={3} />

//       <section className="mx-auto max-w-3xl px-5 py-12">
//         <div className="text-center">
//           <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-[28px] bg-purple-100 text-purple-600">
//             <Search className="h-11 w-11" />
//           </div>
//           <h2 className="text-[32px] font-extrabold tracking-tight text-slate-950">Training your AI agent...</h2>
//           <p className="mt-3 text-[17px] text-slate-500">Scanning {websiteUrl}</p>
//         </div>

//         <div className="mt-10 space-y-4">
//           {trainingSteps.map((item) => {
//             const Icon = item.icon;
//             const style =
//               item.status === "done"
//                 ? "border-emerald-200 bg-emerald-50 text-emerald-700"
//                 : item.status === "active"
//                 ? "border-purple-200 bg-purple-50 text-purple-700"
//                 : "border-slate-200 bg-white text-slate-400 opacity-70";

//             return (
//               <div key={item.title} className={`flex items-center gap-4 rounded-2xl border px-5 py-5 shadow-sm ${style}`}>
//                 <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/70">
//                   <Icon className={`h-5 w-5 ${item.status === "active" ? "animate-spin" : ""}`} />
//                 </div>
//                 <p className="text-[18px] font-bold">{item.title}</p>
//               </div>
//             );
//           })}
//         </div>

//         <div className="mt-12 flex items-center justify-between">
//           <button
//             onClick={() => (window.location.href = "/train")}
//             className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
//           >
//             ← Back
//           </button>
//           <button
//             onClick={() => (window.location.href = "/review-agent")}
//             className="rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600"
//           >
//             Continue →
//           </button>
//         </div>
//       </section>
//     </div>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  Loader2,
  MessageSquare,
  Plus,
  Search,
  Sparkles,
} from "lucide-react";
import AgentSteps from "./training/AgentSteps";

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

const defaultSteps = [
  { key: "scanning", label: "Scanning your website / uploaded files", status: "pending", icon: Search },
  { key: "analyzing", label: "Analyzing your business content", status: "pending", icon: Sparkles },
  { key: "chunking", label: "Chunking and cleaning knowledge", status: "pending", icon: Loader2 },
  { key: "building_knowledge_base", label: "Building knowledge base / AI brain", status: "pending", icon: BookOpen },
  { key: "generating_chat_experience", label: "Generating chat experience", status: "pending", icon: MessageSquare },
];

function getIconForStep(key) {
  if (key === "scanning") return Search;
  if (key === "analyzing") return Sparkles;
  if (key === "chunking") return Loader2;
  if (key === "building_knowledge_base") return BookOpen;
  if (key === "generating_chat_experience") return MessageSquare;
  return Loader2;
}

function statusClasses(status) {
  if (status === "done") return "border-emerald-200 bg-emerald-50 text-emerald-700";
  if (status === "active") return "border-purple-200 bg-purple-50 text-purple-700";
  if (status === "failed") return "border-red-200 bg-red-50 text-red-700";
  return "border-slate-200 bg-white text-slate-400 opacity-70";
}

export default function Step2() {
  const websiteUrl = localStorage.getItem("last_training_url") || "your uploaded content";
  const jobId = localStorage.getItem("active_training_job_id") || "";

  const [job, setJob] = useState(null);
  const [error, setError] = useState("");
  const [isPolling, setIsPolling] = useState(Boolean(jobId));

  const steps = useMemo(() => {
    if (!job?.steps?.length) return defaultSteps;
    return job.steps.map((step) => ({
      ...step,
      icon: getIconForStep(step.key),
    }));
  }, [job]);

  const isCompleted = job?.status === "completed";
  const isFailed = job?.status === "failed";
  const result = job?.result || {};

  useEffect(() => {
    if (!jobId) {
      setError("No active training job found. Please start training again.");
      setIsPolling(false);
      return;
    }

    let intervalId;
    let cancelled = false;

    const fetchStatus = async () => {
      try {
        const token = localStorage.getItem("auth_token");
        const response = await fetch(`${API_BASE_URL}/train-agent/status/${jobId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json().catch(() => null);
        if (!response.ok) {
          throw new Error(data?.detail || data?.message || `Status failed: ${response.status}`);
        }

        if (cancelled) return;

        setJob(data);
        setError("");

        if (data.status === "completed" || data.status === "failed") {
          setIsPolling(false);
          if (intervalId) clearInterval(intervalId);
        }
      } catch (err) {
        if (cancelled) return;
        setError(err.message || "Could not fetch training status.");
      }
    };

    fetchStatus();
    intervalId = setInterval(fetchStatus, 1500);

    return () => {
      cancelled = true;
      if (intervalId) clearInterval(intervalId);
    };
  }, [jobId]);

  return (
    <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
      <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
        <div className="flex items-center justify-between">
          <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
            <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
          </button>
          <p className="text-xs font-semibold text-slate-400">Step 3 of 5</p>
        </div>
      </div>

      <AgentSteps current={3} />

      <section className="mx-auto max-w-3xl px-5 py-12">
        <div className="text-center">
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-[28px] bg-purple-100 text-purple-600">
            {isCompleted ? <CheckCircle2 className="h-11 w-11" /> : isFailed ? <AlertCircle className="h-11 w-11" /> : <Search className="h-11 w-11" />}
          </div>

          <h2 className="text-[32px] font-extrabold tracking-tight text-slate-950">
            {isCompleted ? "Agent trained successfully!" : isFailed ? "Training failed" : "Training your AI agent..."}
          </h2>

          <p className="mt-3 text-[17px] text-slate-500">
            {isCompleted
              ? `Scanned ${result.website_documents || 0} website docs and ${result.uploaded_documents || 0} uploaded docs • Created ${result.chunks_created || 0} knowledge entries`
              : isFailed
              ? job?.error || error || "Something went wrong while training."
              : job?.message || `Scanning ${websiteUrl}`}
          </p>
        </div>

        {error && !isFailed && (
          <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4 text-sm font-semibold text-amber-700">
            {error}
          </div>
        )}

        <div className="mt-10 space-y-4">
          {steps.map((item) => {
            const Icon = item.status === "done" ? CheckCircle2 : item.status === "failed" ? AlertCircle : item.icon;

            return (
              <div key={item.key} className={`flex items-center gap-4 rounded-2xl border px-5 py-5 shadow-sm ${statusClasses(item.status)}`}>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/70">
                  <Icon className={`h-5 w-5 ${item.status === "active" ? "animate-spin" : ""}`} />
                </div>
                <div className="flex-1">
                  <p className="text-[18px] font-bold">{item.label}</p>
                  {item.status === "active" && <p className="mt-1 text-xs font-semibold opacity-80">Currently running...</p>}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 flex items-center justify-between">
          <button
            onClick={() => (window.location.href = "/train")}
            className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
          >
            ← Back
          </button>

          <button
            onClick={() => (window.location.href = "/review-agent")}
            disabled={!isCompleted}
            className="rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isPolling ? "Training..." : isCompleted ? "Continue" : "Waiting..."}
          </button>
        </div>
      </section>
    </div>
  );
}
