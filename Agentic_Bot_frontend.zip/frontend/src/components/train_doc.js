// import React, { useMemo, useRef, useState } from "react";
// import {
//   ArrowLeft,
//   ArrowRight,
//   FileText,
//   Globe,
//   Link as LinkIcon,
//   Loader2,
//   Plus,
//   Sparkles,
//   Trash2,
//   UploadCloud,
//   X,
// } from "lucide-react";

// /**
//  * train_doc.js
//  *
//  * React page for training an AI Agent from:
//  * 1. Website URL
//  * 2. Sitemap URL
//  * 3. Multiple uploaded documents/files
//  *
//  * Backend expected endpoint:
//  * POST /train-agent
//  *
//  * FormData fields sent:
//  * - website_url
//  * - sitemap_url
//  * - crawl_type
//  * - content_type
//  * - files[]
//  *
//  * Put this file in:
//  * src/pages/train_doc.js
//  * or
//  * src/components/train_doc.js
//  */

// const API_BASE_URL =
//   process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

// const CRAWL_TYPES = [
//   {
//     value: "single_page",
//     label: "Single Page",
//     helper: "Scrape only the given URL.",
//   },
//   {
//     value: "full_website",
//     label: "Full Website",
//     helper: "Let Selenium discover and scrape internal links.",
//   },
//   {
//     value: "sitemap",
//     label: "Sitemap URL",
//     helper: "Best for websites with many pages.",
//   },
// ];

// const CONTENT_TYPES = [
//   "Website",
//   "PDF Documents",
//   "Word Documents",
//   "FAQ",
//   "Product Catalog",
//   "Company Profile",
//   "Policy / Terms",
//   "Mixed Content",
// ];

// const ALLOWED_FILE_TYPES = [
//   ".pdf",
//   ".doc",
//   ".docx",
//   ".txt",
//   ".csv",
//   ".json",
//   ".xlsx",
//   ".xls",
// ];

// function formatBytes(bytes) {
//   if (!bytes && bytes !== 0) return "";
//   const sizes = ["Bytes", "KB", "MB", "GB"];
//   if (bytes === 0) return "0 Bytes";
//   const i = Math.floor(Math.log(bytes) / Math.log(1024));
//   return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${sizes[i]}`;
// }

// function isValidUrl(value) {
//   if (!value) return true;
//   try {
//     const url = new URL(value);
//     return url.protocol === "http:" || url.protocol === "https:";
//   } catch {
//     return false;
//   }
// }

// export default function TrainDoc() {
//   const fileInputRef = useRef(null);

//   const [websiteUrl, setWebsiteUrl] = useState("");
//   const [sitemapUrl, setSitemapUrl] = useState("");
//   const [crawlType, setCrawlType] = useState("single_page");
//   const [contentType, setContentType] = useState("Mixed Content");
//   const [files, setFiles] = useState([]);

//   const [isTraining, setIsTraining] = useState(false);
//   const [status, setStatus] = useState({
//     type: "",
//     message: "",
//     data: null,
//   });

//   const totalFilesSize = useMemo(() => {
//     return files.reduce((sum, file) => sum + file.size, 0);
//   }, [files]);

//   const canSubmit = useMemo(() => {
//     const hasUrl = websiteUrl.trim() || sitemapUrl.trim();
//     const hasFiles = files.length > 0;
//     return hasUrl || hasFiles;
//   }, [websiteUrl, sitemapUrl, files]);

//   const handleFiles = (selectedFiles) => {
//     const incomingFiles = Array.from(selectedFiles || []);

//     const filteredFiles = incomingFiles.filter((file) => {
//       const fileName = file.name.toLowerCase();
//       return ALLOWED_FILE_TYPES.some((ext) => fileName.endsWith(ext));
//     });

//     setFiles((prev) => {
//       const existingKeys = new Set(
//         prev.map((file) => `${file.name}-${file.size}-${file.lastModified}`)
//       );

//       const uniqueFiles = filteredFiles.filter((file) => {
//         const key = `${file.name}-${file.size}-${file.lastModified}`;
//         return !existingKeys.has(key);
//       });

//       return [...prev, ...uniqueFiles];
//     });

//     if (incomingFiles.length !== filteredFiles.length) {
//       setStatus({
//         type: "warning",
//         message:
//           "Some unsupported files were skipped. Allowed: PDF, DOC, DOCX, TXT, CSV, JSON, XLS, XLSX.",
//         data: null,
//       });
//     }
//   };

//   const removeFile = (indexToRemove) => {
//     setFiles((prev) => prev.filter((_, index) => index !== indexToRemove));
//   };

//   const resetForm = () => {
//     setWebsiteUrl("");
//     setSitemapUrl("");
//     setCrawlType("single_page");
//     setContentType("Mixed Content");
//     setFiles([]);
//     setStatus({ type: "", message: "", data: null });
//     if (fileInputRef.current) fileInputRef.current.value = "";
//   };

//   const trainAgent = async () => {
//     setStatus({ type: "", message: "", data: null });

//     if (!canSubmit) {
//       setStatus({
//         type: "error",
//         message: "Please enter a website/sitemap URL or upload at least one file.",
//         data: null,
//       });
//       return;
//     }

//     if (!isValidUrl(websiteUrl.trim())) {
//       setStatus({
//         type: "error",
//         message: "Please enter a valid website URL.",
//         data: null,
//       });
//       return;
//     }

//     if (!isValidUrl(sitemapUrl.trim())) {
//       setStatus({
//         type: "error",
//         message: "Please enter a valid sitemap URL.",
//         data: null,
//       });
//       return;
//     }

//     if (crawlType === "sitemap" && !sitemapUrl.trim()) {
//       setStatus({
//         type: "error",
//         message: "Please enter sitemap URL when crawl type is Sitemap.",
//         data: null,
//       });
//       return;
//     }

//     const formData = new FormData();
//     formData.append("website_url", websiteUrl.trim());
//     formData.append("sitemap_url", sitemapUrl.trim());
//     formData.append("crawl_type", crawlType);
//     formData.append("content_type", contentType);

//     files.forEach((file) => {
//       formData.append("files", file);
//     });

//     try {
//       setIsTraining(true);

//       // const response = await fetch(`${API_BASE_URL}/train-agent`, {
//       //   method: "POST",
//       //   body: formData,
//       // });
//       const token = localStorage.getItem("auth_token");

//       const response = await fetch(`${API_BASE_URL}/train-agent`, {
//         method: "POST",
//         headers: {
//           Authorization: `Bearer ${token}`,   // ✅ ADD THIS
//         },
//         body: formData,
//       });


//       let result = null;
//       try {
//         result = await response.json();
//       } catch {
//         result = null;
//       }

//       if (!response.ok) {
//         throw new Error(
//           result?.detail ||
//             result?.message ||
//             `Training failed with status ${response.status}`
//         );
//       }

//       setStatus({
//         type: "success",
//         message:
//           result?.message ||
//           "Agent training started successfully. Knowledge base is being prepared.",
//         data: result,
//       });
//     } catch (error) {
//       setStatus({
//         type: "error",
//         message: error.message || "Something went wrong while training agent.",
//         data: null,
//       });
//     } finally {
//       setIsTraining(false);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-slate-50 text-slate-900">
//       <main className="px-4 py-8 sm:px-6">
//         <section className="mx-auto max-w-6xl rounded-sm bg-white shadow-sm">
//          <div className="mx-auto max-w-4xl px-5 py-8">
//             <div className="text-center">
//               <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-purple-100">
//                 <Sparkles className="h-10 w-10 text-purple-600" />
//               </div>

//               <h3 className="text-3xl font-extrabold tracking-tight">
//                 Train your AI agent
//               </h3>
//               <p className="mx-auto mt-3 max-w-xl text-base leading-7 text-slate-500">
//                 Add website URL, sitemap URL, and documents. We will combine all
//                 content for your agent knowledge base.
//               </p>
//             </div>

//             <div className="mt-8 grid gap-5">
//               <div className="grid gap-4 lg:grid-cols-2">
//                 <label className="block">
//                   <span className="mb-2 block text-sm font-semibold text-slate-700">
//                     Website URL
//                   </span>
//                   <div className="flex items-center rounded-xl border border-purple-300 bg-white px-4 py-3 shadow-sm focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
//                     <Globe className="mr-3 h-5 w-5 text-slate-400" />
//                     <input
//                       value={websiteUrl}
//                       onChange={(event) => setWebsiteUrl(event.target.value)}
//                       placeholder="https://yourwebsite.com"
//                       className="w-full bg-transparent text-base outline-none placeholder:text-slate-400"
//                     />
//                   </div>
//                 </label>

//                 <label className="block">
//                   <span className="mb-2 block text-sm font-semibold text-slate-700">
//                     Sitemap URL
//                   </span>
//                   <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
//                     <LinkIcon className="mr-3 h-5 w-5 text-slate-400" />
//                     <input
//                       value={sitemapUrl}
//                       onChange={(event) => setSitemapUrl(event.target.value)}
//                       placeholder="https://yourwebsite.com/sitemap.xml"
//                       className="w-full bg-transparent text-base outline-none placeholder:text-slate-400"
//                     />
//                   </div>
//                 </label>
//               </div>

//               <div className="grid gap-4 lg:grid-cols-2">
//                 <label className="block">
//                   <span className="mb-2 block text-sm font-semibold text-slate-700">
//                     Crawl Type
//                   </span>
//                   <select
//                     value={crawlType}
//                     onChange={(event) => setCrawlType(event.target.value)}
//                     className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-base outline-none shadow-sm focus:border-purple-500 focus:ring-2 focus:ring-purple-100"
//                   >
//                     {CRAWL_TYPES.map((type) => (
//                       <option key={type.value} value={type.value}>
//                         {type.label}
//                       </option>
//                     ))}
//                   </select>
//                   <p className="mt-2 text-xs text-slate-400">
//                     {CRAWL_TYPES.find((type) => type.value === crawlType)?.helper}
//                   </p>
//                 </label>

//                 <label className="block">
//                   <span className="mb-2 block text-sm font-semibold text-slate-700">
//                     Content Type
//                   </span>
//                   <select
//                     value={contentType}
//                     onChange={(event) => setContentType(event.target.value)}
//                     className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-base outline-none shadow-sm focus:border-purple-500 focus:ring-2 focus:ring-purple-100"
//                   >
//                     {CONTENT_TYPES.map((type) => (
//                       <option key={type} value={type}>
//                         {type}
//                       </option>
//                     ))}
//                   </select>
//                 </label>
//               </div>

//               <div>
//                 <span className="mb-2 block text-sm font-semibold text-slate-700">
//                   Upload Documents / Attachments
//                 </span>

//                 <div
//                   onDragOver={(event) => event.preventDefault()}
//                   onDrop={(event) => {
//                     event.preventDefault();
//                     handleFiles(event.dataTransfer.files);
//                   }}
//                   className="rounded-2xl border-2 border-dashed border-purple-200 bg-purple-50/40 p-6 text-center"
//                 >
//                   <UploadCloud className="mx-auto h-10 w-10 text-purple-500" />

//                   <p className="mt-3 text-sm font-semibold text-slate-700">
//                     Drag and drop files here
//                   </p>
//                   <p className="mt-1 text-xs text-slate-400">
//                     PDF, DOC, DOCX, TXT, CSV, JSON, XLS, XLSX
//                   </p>

//                   <button
//                     type="button"
//                     onClick={() => fileInputRef.current?.click()}
//                     className="mt-4 rounded-xl bg-purple-500 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-purple-600 disabled:opacity-60"
//                     disabled={isTraining}
//                   >
//                     Select Files
//                   </button>

//                   <input
//                     ref={fileInputRef}
//                     type="file"
//                     multiple
//                     hidden
//                     accept={ALLOWED_FILE_TYPES.join(",")}
//                     onChange={(event) => handleFiles(event.target.files)}
//                   />
//                 </div>
//               </div>

//               {files.length > 0 && (
//                 <div className="rounded-2xl border border-slate-200 bg-white p-4">
//                   <div className="mb-3 flex items-center justify-between">
//                     <h4 className="text-sm font-bold text-slate-800">
//                       Selected Files ({files.length})
//                     </h4>
//                     <span className="text-xs text-slate-400">
//                       Total: {formatBytes(totalFilesSize)}
//                     </span>
//                   </div>

//                   <div className="max-h-56 space-y-2 overflow-y-auto pr-1">
//                     {files.map((file, index) => (
//                       <div
//                         key={`${file.name}-${file.size}-${file.lastModified}`}
//                         className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-4 py-3"
//                       >
//                         <div className="flex min-w-0 items-center gap-3">
//                           <FileText className="h-5 w-5 flex-shrink-0 text-purple-500" />
//                           <div className="min-w-0">
//                             <p className="truncate text-sm font-semibold text-slate-700">
//                               {file.name}
//                             </p>
//                             <p className="text-xs text-slate-400">
//                               {formatBytes(file.size)}
//                             </p>
//                           </div>
//                         </div>

//                         <button
//                           type="button"
//                           onClick={() => removeFile(index)}
//                           className="ml-3 rounded-lg p-2 text-slate-400 hover:bg-white hover:text-red-500"
//                           disabled={isTraining}
//                         >
//                           <Trash2 className="h-4 w-4" />
//                         </button>
//                       </div>
//                     ))}
//                   </div>
//                 </div>
//               )}

//               {status.message && (
//                 <div
//                   className={[
//                     "rounded-xl border px-4 py-3 text-sm",
//                     status.type === "success"
//                       ? "border-green-200 bg-green-50 text-green-700"
//                       : status.type === "warning"
//                       ? "border-amber-200 bg-amber-50 text-amber-700"
//                       : "border-red-200 bg-red-50 text-red-700",
//                   ].join(" ")}
//                 >
//                   {status.message}

//                   {status.data?.chunks_created !== undefined && (
//                     <div className="mt-2 text-xs">
//                       Chunks created: {status.data.chunks_created}
//                     </div>
//                   )}
//                 </div>
//               )}

//               <div className="text-center text-xs leading-5 text-slate-400">
//                 Your backend should combine scraped website data + uploaded file
//                 text, then create chunks and FAISS index for RAG.
//               </div>
//             </div>

//             <div className="mt-10 border-t border-slate-100 pt-5">
//               <div className="flex items-center justify-between">
//                 <button
//                   type="button"
//                   className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
//                 >
//                   <ArrowLeft className="h-4 w-4" />
//                   Back
//                 </button>

//                 <div className="flex items-center gap-3">
//                   <button
//                     type="button"
//                     onClick={resetForm}
//                     disabled={isTraining}
//                     className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-500 shadow-sm hover:bg-slate-50 disabled:opacity-60"
//                   >
//                     Reset
//                   </button>

//                   <button
//                     type="button"
//                     onClick={trainAgent}
//                     disabled={isTraining || !canSubmit}
//                     className="inline-flex items-center gap-2 rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600 disabled:cursor-not-allowed disabled:opacity-60"
//                   >
//                     {isTraining ? (
//                       <>
//                         <Loader2 className="h-4 w-4 animate-spin" />
//                         Training...
//                       </>
//                     ) : (
//                       <>
//                         <Sparkles className="h-4 w-4" />
//                         Train My Agent
//                       </>
//                     )}
//                   </button>

//                   <button
//                     type="button"
//                     disabled={status.type !== "success"}
//                     className="inline-flex items-center gap-2 rounded-xl bg-purple-300 px-6 py-3 text-sm font-bold text-white shadow-sm disabled:cursor-not-allowed disabled:opacity-60"
//                   >
//                     Continue
//                     <ArrowRight className="h-4 w-4" />
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </section>
//       </main>
//     </div>
//   );
// }
 
import React, { useMemo, useRef, useState } from "react";
import AgentSteps from "./training/AgentSteps";

import {
  ArrowLeft,
  ArrowRight,
  FileText,
  Globe,
  Link as LinkIcon,
  Loader2,
  Plus,
  Sparkles,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";

/**
 * train_doc.js
 *
 * React page for training an AI Agent from:
 * 1. Website URL
 * 2. Sitemap URL
 * 3. Multiple uploaded documents/files
 *
 * Backend expected endpoint:
 * POST /train-agent
 *
 * FormData fields sent:
 * - website_url
 * - sitemap_url
 * - crawl_type
 * - content_type
 * - files[]
 *
 * Put this file in:
 * src/pages/train_doc.js
 * or
 * src/components/train_doc.js
 */

const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

const CRAWL_TYPES = [
  {
    value: "single_page",
    label: "Single Page",
    helper: "Scrape only the given URL.",
  },
  {
    value: "full_website",
    label: "Full Website",
    helper: "Let Selenium discover and scrape internal links.",
  },
  {
    value: "sitemap",
    label: "Sitemap URL",
    helper: "Best for websites with many pages.",
  },
];

const CONTENT_TYPES = [
  "Website",
  "PDF Documents",
  "Word Documents",
  "FAQ",
  "Product Catalog",
  "Company Profile",
  "Policy / Terms",
  "Mixed Content",
];

const ALLOWED_FILE_TYPES = [
  ".pdf",
  ".doc",
  ".docx",
  ".txt",
  ".csv",
  ".json",
  ".xlsx",
  ".xls",
];

function formatBytes(bytes) {
  if (!bytes && bytes !== 0) return "";
  const sizes = ["Bytes", "KB", "MB", "GB"];
  if (bytes === 0) return "0 Bytes";
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${sizes[i]}`;
}

function isValidUrl(value) {
  if (!value) return true;
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export default function TrainDoc() {
  const fileInputRef = useRef(null);

  const [websiteUrl, setWebsiteUrl] = useState("");
  const [sitemapUrl, setSitemapUrl] = useState("");
  const [crawlType, setCrawlType] = useState("single_page");
  const [contentType, setContentType] = useState("Mixed Content");
  const [files, setFiles] = useState([]);

  const [isTraining, setIsTraining] = useState(false);
  const [status, setStatus] = useState({
    type: "",
    message: "",
    data: null,
  });

  const totalFilesSize = useMemo(() => {
    return files.reduce((sum, file) => sum + file.size, 0);
  }, [files]);

  const canSubmit = useMemo(() => {
    const hasUrl = websiteUrl.trim() || sitemapUrl.trim();
    const hasFiles = files.length > 0;
    return hasUrl || hasFiles;
  }, [websiteUrl, sitemapUrl, files]);

  const handleFiles = (selectedFiles) => {
    const incomingFiles = Array.from(selectedFiles || []);

    const filteredFiles = incomingFiles.filter((file) => {
      const fileName = file.name.toLowerCase();
      return ALLOWED_FILE_TYPES.some((ext) => fileName.endsWith(ext));
    });

    setFiles((prev) => {
      const existingKeys = new Set(
        prev.map((file) => `${file.name}-${file.size}-${file.lastModified}`)
      );

      const uniqueFiles = filteredFiles.filter((file) => {
        const key = `${file.name}-${file.size}-${file.lastModified}`;
        return !existingKeys.has(key);
      });

      return [...prev, ...uniqueFiles];
    });

    if (incomingFiles.length !== filteredFiles.length) {
      setStatus({
        type: "warning",
        message:
          "Some unsupported files were skipped. Allowed: PDF, DOC, DOCX, TXT, CSV, JSON, XLS, XLSX.",
        data: null,
      });
    }
  };

  const removeFile = (indexToRemove) => {
    setFiles((prev) => prev.filter((_, index) => index !== indexToRemove));
  };

  const resetForm = () => {
    setWebsiteUrl("");
    setSitemapUrl("");
    setCrawlType("single_page");
    setContentType("Mixed Content");
    setFiles([]);
    setStatus({ type: "", message: "", data: null });
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const trainAgent = async () => {
    setStatus({ type: "", message: "", data: null });

    if (!canSubmit) {
      setStatus({
        type: "error",
        message: "Please enter a website/sitemap URL or upload at least one file.",
        data: null,
      });
      return;
    }

    if (!isValidUrl(websiteUrl.trim())) {
      setStatus({
        type: "error",
        message: "Please enter a valid website URL.",
        data: null,
      });
      return;
    }

    if (!isValidUrl(sitemapUrl.trim())) {
      setStatus({
        type: "error",
        message: "Please enter a valid sitemap URL.",
        data: null,
      });
      return;
    }

    if (crawlType === "sitemap" && !sitemapUrl.trim()) {
      setStatus({
        type: "error",
        message: "Please enter sitemap URL when crawl type is Sitemap.",
        data: null,
      });
      return;
    }

    const formData = new FormData();
    formData.append("website_url", websiteUrl.trim());
    formData.append("sitemap_url", sitemapUrl.trim());
    formData.append("crawl_type", crawlType);
    formData.append("content_type", contentType);

    files.forEach((file) => {
      formData.append("files", file);
    });

    try {
      setIsTraining(true);

      // const response = await fetch(`${API_BASE_URL}/train-agent`, {
      //   method: "POST",
      //   body: formData,
      // });
      const token = localStorage.getItem("auth_token");

      const response = await fetch(`${API_BASE_URL}/train-agent/start`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });


      let result = null;
      try {
        result = await response.json();
      } catch {
        result = null;
      }

      if (!response.ok) {
        throw new Error(
          result?.detail ||
            result?.message ||
            `Training failed with status ${response.status}`
        );
      }

      if (result?.job_id) {
        localStorage.setItem("active_training_job_id", result.job_id);
        localStorage.setItem("last_training_url", websiteUrl.trim() || sitemapUrl.trim() || "Uploaded files");
        window.location.href = "/step2";
        return;
      }

      setStatus({
        type: "success",
        message:
          result?.message ||
          "Agent training started successfully. Knowledge base is being prepared.",
        data: result,
      });
    } catch (error) {
      setStatus({
        type: "error",
        message: error.message || "Something went wrong while training agent.",
        data: null,
      });
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-72px)] bg-slate-50 text-slate-900">
      <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
        <div className="flex items-center justify-between">
          <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
            <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
          </button>
          <p className="text-xs font-semibold text-slate-400">Step 2 of 4</p>
        </div>
      </div>
      <AgentSteps current={2} />
      <main className="px-4 py-8 sm:px-6">
        <section className="mx-auto max-w-6xl rounded-sm bg-white shadow-sm">
         <div className="mx-auto max-w-4xl px-5 py-8">
            <div className="text-center">
              <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-purple-100">
                <Sparkles className="h-10 w-10 text-purple-600" />
              </div>

              <h3 className="text-3xl font-extrabold tracking-tight">
                Train your AI agent
              </h3>
              <p className="mx-auto mt-3 max-w-xl text-base leading-7 text-slate-500">
                Add website URL, sitemap URL, and documents. We will combine all
                content for your agent knowledge base.
              </p>
            </div>

            <div className="mt-8 grid gap-5">
              <div className="grid gap-4 lg:grid-cols-2">
                <label className="block">
                  <span className="mb-2 block text-sm font-semibold text-slate-700">
                    Website URL
                  </span>
                  <div className="flex items-center rounded-xl border border-purple-300 bg-white px-4 py-3 shadow-sm focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
                    <Globe className="mr-3 h-5 w-5 text-slate-400" />
                    <input
                      value={websiteUrl}
                      onChange={(event) => setWebsiteUrl(event.target.value)}
                      placeholder="https://yourwebsite.com"
                      className="w-full bg-transparent text-base outline-none placeholder:text-slate-400"
                    />
                  </div>
                </label>

                <label className="block">
                  <span className="mb-2 block text-sm font-semibold text-slate-700">
                    Sitemap URL
                  </span>
                  <div className="flex items-center rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-100">
                    <LinkIcon className="mr-3 h-5 w-5 text-slate-400" />
                    <input
                      value={sitemapUrl}
                      onChange={(event) => setSitemapUrl(event.target.value)}
                      placeholder="https://yourwebsite.com/sitemap.xml"
                      className="w-full bg-transparent text-base outline-none placeholder:text-slate-400"
                    />
                  </div>
                </label>
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <label className="block">
                  <span className="mb-2 block text-sm font-semibold text-slate-700">
                    Crawl Type
                  </span>
                  <select
                    value={crawlType}
                    onChange={(event) => setCrawlType(event.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-base outline-none shadow-sm focus:border-purple-500 focus:ring-2 focus:ring-purple-100"
                  >
                    {CRAWL_TYPES.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                  <p className="mt-2 text-xs text-slate-400">
                    {CRAWL_TYPES.find((type) => type.value === crawlType)?.helper}
                  </p>
                </label>

                <label className="block">
                  <span className="mb-2 block text-sm font-semibold text-slate-700">
                    Content Type
                  </span>
                  <select
                    value={contentType}
                    onChange={(event) => setContentType(event.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-base outline-none shadow-sm focus:border-purple-500 focus:ring-2 focus:ring-purple-100"
                  >
                    {CONTENT_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <div>
                <span className="mb-2 block text-sm font-semibold text-slate-700">
                  Upload Documents / Attachments
                </span>

                <div
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={(event) => {
                    event.preventDefault();
                    handleFiles(event.dataTransfer.files);
                  }}
                  className="rounded-2xl border-2 border-dashed border-purple-200 bg-purple-50/40 p-6 text-center"
                >
                  <UploadCloud className="mx-auto h-10 w-10 text-purple-500" />

                  <p className="mt-3 text-sm font-semibold text-slate-700">
                    Drag and drop files here
                  </p>
                  <p className="mt-1 text-xs text-slate-400">
                    PDF, DOC, DOCX, TXT, CSV, JSON, XLS, XLSX
                  </p>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-4 rounded-xl bg-purple-500 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-purple-600 disabled:opacity-60"
                    disabled={isTraining}
                  >
                    Select Files
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    hidden
                    accept={ALLOWED_FILE_TYPES.join(",")}
                    onChange={(event) => handleFiles(event.target.files)}
                  />
                </div>
              </div>

              {files.length > 0 && (
                <div className="rounded-2xl border border-slate-200 bg-white p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <h4 className="text-sm font-bold text-slate-800">
                      Selected Files ({files.length})
                    </h4>
                    <span className="text-xs text-slate-400">
                      Total: {formatBytes(totalFilesSize)}
                    </span>
                  </div>

                  <div className="max-h-56 space-y-2 overflow-y-auto pr-1">
                    {files.map((file, index) => (
                      <div
                        key={`${file.name}-${file.size}-${file.lastModified}`}
                        className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-4 py-3"
                      >
                        <div className="flex min-w-0 items-center gap-3">
                          <FileText className="h-5 w-5 flex-shrink-0 text-purple-500" />
                          <div className="min-w-0">
                            <p className="truncate text-sm font-semibold text-slate-700">
                              {file.name}
                            </p>
                            <p className="text-xs text-slate-400">
                              {formatBytes(file.size)}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="ml-3 rounded-lg p-2 text-slate-400 hover:bg-white hover:text-red-500"
                          disabled={isTraining}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {status.message && (
                <div
                  className={[
                    "rounded-xl border px-4 py-3 text-sm",
                    status.type === "success"
                      ? "border-green-200 bg-green-50 text-green-700"
                      : status.type === "warning"
                      ? "border-amber-200 bg-amber-50 text-amber-700"
                      : "border-red-200 bg-red-50 text-red-700",
                  ].join(" ")}
                >
                  {status.message}

                  {status.data?.chunks_created !== undefined && (
                    <div className="mt-2 text-xs">
                      Chunks created: {status.data.chunks_created}
                    </div>
                  )}
                </div>
              )}

              <div className="text-center text-xs leading-5 text-slate-400">
                Your backend should combine scraped website data + uploaded file
                text, then create chunks and FAISS index for RAG.
              </div>
            </div>

            <div className="mt-10 border-t border-slate-100 pt-5">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </button>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={resetForm}
                    disabled={isTraining}
                    className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-500 shadow-sm hover:bg-slate-50 disabled:opacity-60"
                  >
                    Reset
                  </button>

                  <button
                    type="button"
                    onClick={trainAgent}
                    disabled={isTraining || !canSubmit}
                    className="inline-flex items-center gap-2 rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {isTraining ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Training...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4" />
                        Train My Agent
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => (window.location.href = "/step2")}
                    disabled={status.type !== "success"}
                    className="inline-flex items-center gap-2 rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    Continue
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
