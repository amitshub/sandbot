import React from "react";
import { Bot, MessageSquare, Plus, Sparkles } from "lucide-react";
import AgentSteps from "./training/AgentSteps";

export default function AgentTypePage() {
  return (
    <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
      <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
        <div className="flex items-center justify-between">
          <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
            <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
          </button>
          <p className="text-xs font-semibold text-slate-400">Step 1 of 4</p>
        </div>
      </div>

      <AgentSteps current={1} />

      <section className="mx-auto max-w-5xl px-5 py-12">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-[28px] bg-purple-100 text-purple-600">
            <Sparkles className="h-11 w-11" />
          </div>
          <h2 className="text-[32px] font-extrabold tracking-tight text-slate-950">Create your AI agent</h2>
          <p className="mx-auto mt-3 max-w-xl text-[17px] leading-7 text-slate-500">
            Choose what type of agent you want to create. This will start your tenant training flow.
          </p>
        </div>

        <div className="mx-auto mt-10 grid max-w-4xl gap-5 md:grid-cols-2">
          <button
            type="button"
            onClick={() => (window.location.href = "/train")}
            className="rounded-3xl border-2 border-purple-500 bg-white p-7 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-100 text-purple-600">
              <MessageSquare className="h-7 w-7" />
            </div>
            <h3 className="mt-6 text-xl font-extrabold text-slate-950">Chat Agent</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Train your website/document based chatbot for web and WhatsApp conversations.
            </p>
          </button>

          <button
            type="button"
            className="rounded-3xl border border-slate-200 bg-white p-7 text-left opacity-70 shadow-sm"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-500">
              <Bot className="h-7 w-7" />
            </div>
            <h3 className="mt-6 text-xl font-extrabold text-slate-950">Voice Agent</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">Voice setup can be added later.</p>
          </button>
        </div>

        <div className="mx-auto mt-14 flex max-w-4xl items-center justify-between">
          <button className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm">
            ← Back
          </button>
          <button
            onClick={() => (window.location.href = "/train")}
            className="rounded-xl bg-purple-500 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600"
          >
            Continue →
          </button>
        </div>
      </section>
    </div>
  );
}
