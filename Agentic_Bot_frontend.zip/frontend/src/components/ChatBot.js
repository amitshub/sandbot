// import React, { useEffect, useMemo, useRef, useState } from "react";
// import { ArrowLeft, Bot, Loader2, MessageCircle, RefreshCcw, Send, User } from "lucide-react";

// const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

// function makeSessionId() {
//   const old = localStorage.getItem("agent_chat_session_id");
//   if (old) return old;
//   const id = `session_${Date.now()}_${Math.random().toString(16).slice(2)}`;
//   localStorage.setItem("agent_chat_session_id", id);
//   return id;
// }

// function timeNow() {
//   return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
// }

// export default function ChatBot() {
//   const bottomRef = useRef(null);
//   const [sessionId, setSessionId] = useState(makeSessionId);
//   const [message, setMessage] = useState("");
//   const [isSending, setIsSending] = useState(false);
//   const [error, setError] = useState("");
//   const [messages, setMessages] = useState([
//     {
//       id: "welcome",
//       role: "bot",
//       text: "Hi! How can I help you today?",
//       time: timeNow(),
//       sources: [],
//     },
//   ]);

//   const canSend = useMemo(() => message.trim() && !isSending, [message, isSending]);

//   useEffect(() => {
//     bottomRef.current?.scrollIntoView({ behavior: "smooth" });
//   }, [messages, isSending]);

//   const resetChat = () => {
//     const id = `session_${Date.now()}_${Math.random().toString(16).slice(2)}`;
//     localStorage.setItem("agent_chat_session_id", id);
//     setSessionId(id);
//     setError("");
//     setMessages([
//       { id: "welcome", role: "bot", text: "New chat started. Ask your trained bot a question.", time: timeNow(), sources: [] },
//     ]);
//   };

//   const sendMessage = async () => {
//     const clean = message.trim();
//     if (!clean || isSending) return;

//     setMessages((prev) => [...prev, { id: `u_${Date.now()}`, role: "user", text: clean, time: timeNow(), sources: [] }]);
//     setMessage("");
//     setError("");
//     setIsSending(true);

//     try {
//       const token = localStorage.getItem("auth_token");

//       const response = await fetch(`${API_BASE_URL}/chat`, {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ message: clean, session_id: sessionId, top_k: 5 }),
//       });
      
//       const result = await response.json().catch(() => null);
//       if (!response.ok) throw new Error(result?.detail || result?.message || `Chat failed: ${response.status}`);

//       if (result?.session_id && result.session_id !== sessionId) {
//         localStorage.setItem("agent_chat_session_id", result.session_id);
//         setSessionId(result.session_id);
//       }

//       setMessages((prev) => [
//         ...prev,
//         {
//           id: `b_${Date.now()}`,
//           role: "bot",
//           text: result?.answer || "I could not create an answer.",
//           time: timeNow(),
//           sources: result?.sources || [],
//         },
//       ]);
//     } catch (err) {
//       const msg = err.message || "Something went wrong while chatting.";
//       setError(msg);
//       setMessages((prev) => [...prev, { id: `e_${Date.now()}`, role: "bot", text: msg, time: timeNow(), sources: [], isError: true }]);
//     } finally {
//       setIsSending(false);
//     }
//   };

//   const onKeyDown = (e) => {
//     if (e.key === "Enter" && !e.shiftKey) {
//       e.preventDefault();
//       sendMessage();
//     }
//   };

//   return (
//     <div className="min-h-screen bg-slate-100 text-slate-900">
//       <main className="mx-auto flex min-h-screen max-w-5xl flex-col px-3 py-4 sm:px-6">
//         <div className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
//           <header className="flex items-center justify-between bg-purple-600 px-4 py-4 text-white sm:px-6">
//             <div className="flex items-center gap-3">
//               <button type="button" onClick={() => (window.location.href = "/")} className="rounded-full p-2 hover:bg-white/10">
//                 <ArrowLeft className="h-5 w-5" />
//               </button>
//               <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/15">
//                 <MessageCircle className="h-6 w-6" />
//               </div>
//               <div>
//                 <h2 className="text-base font-bold sm:text-lg">Training Test Chat</h2>
//                 <p className="text-xs text-purple-100">Answers from your FAISS knowledge base</p>
//               </div>
//             </div>
//             <button type="button" onClick={resetChat} className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20">
//               <RefreshCcw className="h-4 w-4" /> New Chat
//             </button>
//           </header>

//           <section className="h-[calc(100vh-190px)] min-h-[520px] overflow-y-auto bg-[linear-gradient(135deg,#f8fafc_0%,#eef2ff_100%)] px-3 py-5 sm:px-6">
//             <div className="space-y-4">
//               {messages.map((item) => {
//                 const isUser = item.role === "user";
//                 return (
//                   <div key={item.id} className={`flex items-end gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
//                     {!isUser && <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-white text-purple-600 shadow-sm"><Bot className="h-4 w-4" /></div>}
//                     <div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-6 shadow-sm sm:max-w-[70%] ${isUser ? "rounded-br-sm bg-purple-600 text-white" : item.isError ? "rounded-bl-sm border border-red-200 bg-red-50 text-red-700" : "rounded-bl-sm bg-white text-slate-700"}`}>
//                       <p className="whitespace-pre-wrap">{item.text}</p>
//                       {/* {!isUser && item.sources?.length > 0 && (
//                         <div className="mt-3 border-t border-slate-100 pt-2">
//                           <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">Sources</p>
//                           {item.sources.slice(0, 3).map((src, index) => (
//                             <div key={index} className="truncate text-xs text-slate-400" title={src.source || src.title || "Source"}>
//                               {index + 1}. {src.source || src.title || "Trained data"}
//                             </div>
//                           ))} 
//                         </div>
//                       )} */}
//                       <div className={`mt-1 text-right text-[10px] ${isUser ? "text-purple-100" : "text-slate-400"}`}>{item.time}</div>
//                     </div>
//                     {isUser && <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-purple-600 text-white shadow-sm"><User className="h-4 w-4" /></div>}
//                   </div>
//                 );
//               })}
//               {isSending && (
//                 <div className="flex items-end gap-2">
//                   <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-purple-600 shadow-sm"><Bot className="h-4 w-4" /></div>
//                   <div className="rounded-2xl rounded-bl-sm bg-white px-4 py-3 text-sm text-slate-500 shadow-sm"><span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Thinking...</span></div>
//                 </div>
//               )}
//               <div ref={bottomRef} />
//             </div>
//           </section>

//           {error && <div className="border-t border-red-100 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}

//           <footer className="border-t border-slate-200 bg-white p-3 sm:p-4">
//             <div className="flex items-end gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 focus-within:border-purple-400 focus-within:ring-2 focus-within:ring-purple-100">
//               <textarea value={message} onChange={(e) => setMessage(e.target.value)} onKeyDown={onKeyDown} rows={1} placeholder="Ask something from your trained data..." className="max-h-28 min-h-[44px] flex-1 resize-none bg-transparent py-3 text-sm outline-none placeholder:text-slate-400" />
//               <button type="button" onClick={sendMessage} disabled={!canSend} className="mb-1 inline-flex h-11 w-11 items-center justify-center rounded-full bg-purple-600 text-white shadow-sm hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-50">
//                 {isSending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
//               </button>
//             </div>
//             <p className="mt-2 text-center text-[11px] text-slate-400">Local session: {sessionId}</p>
//           </footer>
//         </div>
//       </main>
//     </div>
//   );
// }
 

import React, { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Bot, Loader2, MessageCircle, RefreshCcw, Send, User } from "lucide-react";

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

function getTenantSlug() {
  const path = window.location.pathname;

  // Supports: /chat/t1
  const slashMatch = path.match(/^\/chat\/([^/]+)/);
  if (slashMatch?.[1]) return slashMatch[1];

  // Supports: /chat_t1
  const underscoreMatch = path.match(/^\/chat_([^/]+)/);
  if (underscoreMatch?.[1]) return underscoreMatch[1];

  return localStorage.getItem("public_chat_tenant_slug") || localStorage.getItem("tenant_slug") || "t1";
}

function makeSessionId(tenantSlug) {
  const key = `agent_chat_session_id_${tenantSlug}`;
  const old = localStorage.getItem(key);
  if (old) return old;

  const id = `session_${tenantSlug}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  localStorage.setItem(key, id);
  return id;
}

function timeNow() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}

export default function ChatBot() {
  const bottomRef = useRef(null);
  const tenantSlug = useMemo(() => getTenantSlug(), []);
  const [sessionId, setSessionId] = useState(() => makeSessionId(tenantSlug));

  const customerKey = `public_chat_customer_${tenantSlug}`;
  const savedCustomer = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem(customerKey) || "{}");
    } catch {
      return {};
    }
  }, [customerKey]);

  const [customerName, setCustomerName] = useState(savedCustomer.name || "");
  const [customerEmail, setCustomerEmail] = useState(savedCustomer.email || "");
  const [step, setStep] = useState(savedCustomer.name && savedCustomer.email ? "chat" : "name");

  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState("");
  const [messages, setMessages] = useState([
    {
      id: "welcome",
      role: "bot",
      text: savedCustomer.name && savedCustomer.email ? "Hi! How can I help you today?" : "Hi! Please share your name to start the chat.",
      time: timeNow(),
    },
  ]);

  const canSend = useMemo(() => message.trim() && !isSending, [message, isSending]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isSending]);

  const saveCustomerLocal = (name, email) => {
    localStorage.setItem(customerKey, JSON.stringify({ name, email }));
  };

  const resetChat = () => {
    const key = `agent_chat_session_id_${tenantSlug}`;
    const id = `session_${tenantSlug}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    localStorage.setItem(key, id);
    localStorage.removeItem(customerKey);

    setSessionId(id);
    setCustomerName("");
    setCustomerEmail("");
    setStep("name");
    setError("");
    setMessage("");
    setMessages([
      { id: "welcome", role: "bot", text: "New chat started. Please share your name.", time: timeNow() },
    ]);
  };

  const addUserMessage = (text) => {
    setMessages((prev) => [...prev, { id: `u_${Date.now()}`, role: "user", text, time: timeNow() }]);
  };

  const addBotMessage = (text, isError = false) => {
    setMessages((prev) => [...prev, { id: `b_${Date.now()}_${Math.random()}`, role: "bot", text, time: timeNow(), isError }]);
  };

  const sendMessage = async () => {
    const clean = message.trim();
    if (!clean || isSending) return;

    addUserMessage(clean);
    setMessage("");
    setError("");

    if (step === "name") {
      setCustomerName(clean);
      setStep("email");
      addBotMessage("Thanks. Please share your email address.");
      return;
    }

    if (step === "email") {
      if (!isValidEmail(clean)) {
        addBotMessage("Please enter a valid email address.", true);
        return;
      }

      setCustomerEmail(clean);
      saveCustomerLocal(customerName, clean);
      setStep("chat");
      addBotMessage("Thank you. How can I help you today?");
      return;
    }

    try {
      setIsSending(true);

      const response = await fetch(`${API_BASE_URL}/chat/${tenantSlug}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: clean,
          session_id: sessionId,
          top_k: 5,
          customer_name: customerName,
          customer_email: customerEmail,
        }),
      });

      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.detail || result?.message || `Chat failed: ${response.status}`);

      if (result?.session_id && result.session_id !== sessionId) {
        const key = `agent_chat_session_id_${tenantSlug}`;
        localStorage.setItem(key, result.session_id);
        setSessionId(result.session_id);
      }

      addBotMessage(result?.answer || "I could not create an answer.");
    } catch (err) {
      const msg = err.message || "Something went wrong while chatting.";
      setError(msg);
      addBotMessage(msg, true);
    } finally {
      setIsSending(false);
    }
  };

  const onKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <main className="mx-auto flex min-h-screen max-w-5xl flex-col px-3 py-4 sm:px-6">
        <div className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
          <header className="flex items-center justify-between bg-purple-600 px-4 py-4 text-white sm:px-6">
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => (window.location.href = "/")} className="rounded-full p-2 hover:bg-white/10">
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/15">
                <MessageCircle className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-base font-bold sm:text-lg">Chat Assistant</h2>
                <p className="text-xs text-purple-100">Tenant: {tenantSlug}</p>
              </div>
            </div>
            <button type="button" onClick={resetChat} className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20">
              <RefreshCcw className="h-4 w-4" /> New Chat
            </button>
          </header>

          <section className="h-[calc(100vh-190px)] min-h-[520px] overflow-y-auto bg-[linear-gradient(135deg,#f8fafc_0%,#eef2ff_100%)] px-3 py-5 sm:px-6">
            <div className="space-y-4">
              {messages.map((item) => {
                const isUser = item.role === "user";
                return (
                  <div key={item.id} className={`flex items-end gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
                    {!isUser && <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-white text-purple-600 shadow-sm"><Bot className="h-4 w-4" /></div>}
                    <div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-6 shadow-sm sm:max-w-[70%] ${isUser ? "rounded-br-sm bg-purple-600 text-white" : item.isError ? "rounded-bl-sm border border-red-200 bg-red-50 text-red-700" : "rounded-bl-sm bg-white text-slate-700"}`}>
                      <p className="whitespace-pre-wrap">{item.text}</p>
                      <div className={`mt-1 text-right text-[10px] ${isUser ? "text-purple-100" : "text-slate-400"}`}>{item.time}</div>
                    </div>
                    {isUser && <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-purple-600 text-white shadow-sm"><User className="h-4 w-4" /></div>}
                  </div>
                );
              })}

              {isSending && (
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Loader2 className="h-4 w-4 animate-spin" /> Assistant is typing...
                </div>
              )}

              <div ref={bottomRef} />
            </div>
          </section>

          {error && <div className="border-t border-red-100 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}

          <footer className="border-t border-slate-200 bg-white p-3 sm:p-4">
            <div className="flex items-end gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-2 focus-within:border-purple-400 focus-within:ring-2 focus-within:ring-purple-100">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder={step === "name" ? "Enter your name" : step === "email" ? "Enter your email" : "Type your message..."}
                rows={1}
                className="max-h-32 min-h-[42px] flex-1 resize-none bg-transparent px-3 py-2 text-sm outline-none placeholder:text-slate-400"
              />
              <button
                type="button"
                onClick={sendMessage}
                disabled={!canSend}
                className="inline-flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-2xl bg-purple-600 text-white shadow-sm hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isSending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
              </button>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}
