import React, { useMemo, useState } from "react";
import {
  BookOpen,
  Bot,
  Briefcase,
  CheckCircle2,
  Clock,
  Edit3,
  FileText,
  Globe2,
  MessageSquare,
  Plus,
  Shield,
  Sparkles,
  X,
} from "lucide-react";
import AgentSteps from "./training/AgentSteps";

const DEFAULT_STARTERS = [
  "Track my order",
  "What wall hanger types?",
  "Towel rod pricing?",
  "Bulk order discounts?",
  "Shipping details?",
];

function HeaderStrip() {
  return (
    <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
      <div className="flex items-center justify-between">
        <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
          <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
        </button>
        <div className="flex items-center gap-6">
          <p className="text-xs font-semibold text-slate-400">Step 2 of 4</p>
          <button type="button" className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function SectionCard({ title, icon: Icon, children, action = true, tone = "default" }) {
  return (
    <div
      className={`overflow-hidden rounded-2xl border shadow-sm ${
        tone === "purple" ? "border-purple-200 bg-purple-50/60" : "border-slate-200 bg-white"
      }`}
    >
      <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/70 px-5 py-4">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-slate-500" />
          <h3 className="text-sm font-extrabold text-slate-700">{title}</h3>
        </div>
        {action && (
          <button className="inline-flex items-center gap-1 text-xs font-bold text-purple-600">
            <Edit3 className="h-3.5 w-3.5" /> Edit
          </button>
        )}
      </div>
      <div className="px-5 py-5">{children}</div>
    </div>
  );
}

function TextInput({ value, onChange, placeholder }) {
  return (
    <input
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
    />
  );
}

export default function AgentReviewPage() {
  const [greeting, setGreeting] = useState(
    "Welcome to SonixYH Industries! We manufacture premium stainless steel and aluminium hardware accessories for your home and bathroom needs."
  );
  const [starters, setStarters] = useState(DEFAULT_STARTERS);
  const [newQuestion, setNewQuestion] = useState("");
  const [systemPrompt, setSystemPrompt] = useState(
    "You are a sales-focused chatbot for SonixYH Industries, a premium manufacturer of stainless steel and aluminium hardware accessories for homes and bathrooms. Your primary goal is to convert visitors into customers by showcasing products, highlighting quality, and guiding them toward purchase."
  );
  const [rules, setRules] = useState(
    "- Do not share internal cost structures, supplier agreements, or manufacturing profit margins\n- Do not provide detailed technical specifications beyond what's listed on product pages/material pages\n- Do not invent pricing, discounts, or delivery promises if unavailable"
  );

  const summary = useMemo(
    () => ({ pages: 51, entries: 52, products: 46, other: 6 }),
    []
  );

  const addStarter = () => {
    const clean = newQuestion.trim();
    if (!clean) return;
    setStarters((prev) => [...prev, clean].slice(0, 8));
    setNewQuestion("");
  };

  return (
    <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
      <HeaderStrip />
      <AgentSteps current={2} />

      <section className="mx-auto max-w-[640px] px-5 py-8">
        <div className="mb-6 flex items-center justify-between rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-emerald-700 shadow-sm">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5" />
            <div>
              <p className="text-sm font-extrabold">Agent trained successfully!</p>
              <p className="text-xs font-semibold">Scanned {summary.pages} pages · Created {summary.entries} knowledge entries</p>
            </div>
          </div>
          <button className="text-xs font-extrabold text-emerald-700">Re-scan</button>
        </div>

        <div className="space-y-5">
          <SectionCard title="Business Info" icon={Briefcase}>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-[11px] font-bold text-slate-400">Name</p>
                <p className="mt-1 text-sm font-extrabold text-slate-900">SonixYH Industries</p>
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-400">Industry</p>
                <p className="mt-1 text-sm font-extrabold text-slate-900">Hardware Accessories</p>
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-400">Type</p>
                <p className="mt-1 text-sm font-extrabold text-slate-900">Physical Products</p>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Description" icon={FileText}>
            <p className="text-sm leading-6 text-slate-600">
              SonixYH Industries is a manufacturer and supplier of stainless steel and aluminium hardware accessories for homes and bathrooms. They specialize in wall hangers, towel rods, door kits, bathroom accessories, and decorative brackets in various designs and finishes.
            </p>
          </SectionCard>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center justify-between px-5 py-4">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-purple-500" />
                <p className="text-sm font-extrabold text-slate-700">Knowledge Base</p>
                <span className="rounded-full bg-purple-100 px-2 py-1 text-[10px] font-extrabold text-purple-600">{summary.entries} entries</span>
              </div>
              <button className="text-xs font-bold text-purple-600">+ Add Entry</button>
            </div>
          </div>

          <SectionCard title="What your AI agent knows" icon={Sparkles} action={false} tone="purple">
            <div className="text-sm leading-6 text-purple-700">
              <p className="font-bold">Your AI agent “SonixYH Industries” knows:</p>
              <p>📄 {summary.entries} knowledge base entries from {summary.pages} pages:</p>
              <p className="pl-4">• {summary.products} product/catalog pages</p>
              <p className="pl-4">• {summary.other} other pages (about, contact, services, etc.)</p>
              <p>💡 Your chatbot can answer questions about all of this.</p>
              <p>📚 You can add more knowledge from the dashboard after setup.</p>
            </div>
          </SectionCard>

          <SectionCard title="Chat Experience" icon={MessageSquare} action={false}>
            <label className="block">
              <span className="mb-2 block text-xs font-bold text-slate-500">Greeting Message</span>
              <textarea
                value={greeting}
                onChange={(event) => setGreeting(event.target.value)}
                className="min-h-[82px] w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
              />
            </label>

            <div className="mt-5">
              <p className="mb-2 text-xs font-bold text-slate-500">Starter Questions <span className="font-medium">(max 50 chars each)</span></p>
              <div className="space-y-2">
                {starters.map((question, index) => (
                  <TextInput
                    key={`${question}-${index}`}
                    value={question}
                    onChange={(value) => setStarters((prev) => prev.map((item, i) => (i === index ? value : item)))}
                  />
                ))}
                <div className="flex gap-2">
                  <TextInput value={newQuestion} onChange={setNewQuestion} placeholder="Add question (max 50 chars)..." />
                  <button onClick={addStarter} className="h-10 w-10 rounded-xl bg-purple-100 text-xl font-bold text-purple-600">+</button>
                </div>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="AI Behaviour & Rules" icon={Shield} action={false}>
            <label className="block">
              <span className="mb-2 block text-xs font-bold text-slate-500">System Prompt</span>
              <textarea
                value={systemPrompt}
                onChange={(event) => setSystemPrompt(event.target.value)}
                className="min-h-[126px] w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
              />
              <p className="mt-2 text-[11px] text-slate-400">Instructions that shape how your chatbot behaves. Be specific about tone, boundaries, and goals.</p>
            </label>

            <label className="mt-5 block">
              <span className="mb-2 block text-xs font-bold text-slate-500">Restriction Rules</span>
              <textarea
                value={rules}
                onChange={(event) => setRules(event.target.value)}
                className="min-h-[102px] w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
              />
              <p className="mt-2 text-[11px] text-slate-400">One rule per line. The AI will never share this information.</p>
            </label>
          </SectionCard>

          <SectionCard title="Support Hours" icon={Clock} action={false}>
            <p className="mb-4 text-xs leading-5 text-slate-400">Set your business hours so the chatbot can tell customers when live support is available.</p>
            <div className="grid gap-3 md:grid-cols-2">
              <label>
                <span className="mb-2 block text-xs font-bold text-slate-500">Opening Time</span>
                <select className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none">
                  <option>Not set</option>
                  <option>09:00 AM</option>
                  <option>10:00 AM</option>
                </select>
              </label>
              <label>
                <span className="mb-2 block text-xs font-bold text-slate-500">Closing Time</span>
                <select className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none">
                  <option>Not set</option>
                  <option>06:00 PM</option>
                  <option>07:00 PM</option>
                </select>
              </label>
              <label className="md:col-span-2">
                <span className="mb-2 block text-xs font-bold text-slate-500">Working Days</span>
                <select className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none">
                  <option>Not set</option>
                  <option>Monday to Friday</option>
                  <option>Monday to Saturday</option>
                </select>
              </label>
            </div>
          </SectionCard>

          <div className="flex items-center justify-between pt-6">
            <button
              type="button"
              onClick={() => (window.location.href = "/step2")}
              className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
            >
              ← Back
            </button>
            <button
              type="button"
              onClick={() => (window.location.href = "/step3")}
              className="rounded-xl bg-purple-500 px-7 py-3 text-sm font-extrabold text-white shadow-sm hover:bg-purple-600"
            >
              Continue
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
