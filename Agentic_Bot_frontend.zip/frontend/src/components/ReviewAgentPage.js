// import React from "react";
// import {
//   BookOpen,
//   Bot,
//   Clock,
//   Edit3,
//   MessageSquare,
//   Plus,
//   Shield,
//   Sparkles,
//   X,
// } from "lucide-react";
// import AgentSteps from "./training/AgentSteps";

// export default function ReviewAgentPage() {
//   return (
//     <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
//       <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
//         <div className="flex items-center justify-between">
//           <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
//             <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
//           </button>

//           <div className="flex items-center gap-5">
//             <p className="text-xs font-semibold text-slate-400">Step 4 of 5</p>
           
//             <X className="h-4 w-4 text-slate-400" />
//           </div>
//         </div>
//       </div>

//       <AgentSteps current={4} />

//       <main className="mx-auto max-w-[620px] px-5 py-7">
//         <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4">
//           <div className="flex items-center justify-between">
//             <div>
//               <p className="text-sm font-extrabold text-emerald-700">
//                 Agent trained successfully!
//               </p>
//               <p className="text-xs font-semibold text-emerald-600">
//                 Scanned 51 pages • Created 52 knowledge entries
//               </p>
//             </div>
//             <button className="text-xs font-bold text-emerald-700">
//               Re-scan
//             </button>
//           </div>
//         </div>

//         <Card
//           title="Business Info"
//           icon={Bot}
//           action
//         >
//           <div className="grid grid-cols-3 gap-6 text-sm">
//             <Info label="Name" value="SonixYH Industries" />
//             <Info label="Industry" value="Hardware Accessories" />
//             <Info label="Type" value="Physical Products" />
//           </div>
//         </Card>

//         <Card title="Description" icon={BookOpen} action>
//           <p className="text-sm leading-6 text-slate-600">
//             SonixYH Industries is a manufacturer and supplier of stainless steel
//             and aluminum hardware accessories for homes and bathrooms. They
//             specialize in wall hangers, towel rods, door kits, bathroom
//             accessories, and decorative brackets in various designs and finishes.
//           </p>
//         </Card>

//         <Card title="Knowledge Base" icon={BookOpen}>
//           <div className="flex items-center justify-between">
//             <span className="rounded-full bg-purple-100 px-3 py-1 text-xs font-bold text-purple-600">
//               52 entries
//             </span>
//             <button className="text-xs font-bold text-purple-600">
//               + Add Entry
//             </button>
//           </div>
//         </Card>

//         <div className="mb-5 rounded-2xl border border-purple-200 bg-purple-50 p-5">
//           <div className="mb-4 flex items-center gap-2 text-purple-700">
//             <Sparkles className="h-4 w-4" />
//             <h3 className="text-sm font-extrabold">
//               What your AI agent knows
//             </h3>
//           </div>

//           <div className="text-sm leading-6 text-purple-700">
//             <p>Your AI agent "SonixYH Industries" knows:</p>
//             <p>📄 52 knowledge base entries from 51 pages</p>
//             <p>📦 46 product/catalog pages</p>
//             <p>🌐 6 other pages: about, contact, services, etc.</p>
//             <p>🔍 Your chatbot can answer questions about all of this.</p>
//             <p>📚 You can add more knowledge from the dashboard after setup.</p>
//           </div>
//         </div>

//         <Card title="Chat Experience" icon={MessageSquare}>
//           <Label>Greeting Message</Label>
//           <textarea
//             defaultValue="Welcome to SonixYH Industries! We manufacture premium stainless steel and aluminum hardware accessories for your home and bathroom needs."
//             className="h-20 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
//           />

//           <Label className="mt-4">Starter Questions</Label>
//           {[
//             "Track my order",
//             "What wall hanger types?",
//             "Towel rod pricing?",
//             "Bulk order discounts?",
//             "Shipping details?",
//           ].map((q) => (
//             <input
//               key={q}
//               defaultValue={q}
//               className="mb-2 h-10 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none"
//             />
//           ))}

//           <div className="flex gap-2">
//             <input
//               placeholder="Add question (max 50 chars)..."
//               className="h-10 flex-1 rounded-lg border border-dashed border-slate-300 px-3 text-sm outline-none"
//             />
//             <button className="h-10 w-10 rounded-lg bg-purple-100 text-purple-600">
//               +
//             </button>
//           </div>
//         </Card>

//         <Card title="AI Behaviour & Rules" icon={Shield}>
//           <Label>System Prompt</Label>
//           <textarea
//             defaultValue={`You are a sales-focused chatbot for SonixYH Industries, a premium manufacturer of stainless steel and aluminum hardware accessories for homes and bathrooms.

// Your primary goal is to convert visitors into customers by showcasing products, highlighting quality, and guiding them toward purchase.`}
//             className="h-32 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
//           />

//           <Label className="mt-4">Restriction Rules</Label>
//           <textarea
//             defaultValue={`- Do not share internal cost structures, supplier agreements, or manufacturing profit margins
// - Do not provide detailed technical specifications beyond what is listed on product pages`}
//             className="h-24 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
//           />
//         </Card>

//         <Card title="Support Hours" icon={Clock}>
//           <p className="mb-4 text-xs text-slate-400">
//             Set your business hours so the chatbot can tell customers when live
//             support is available.
//           </p>

//           <div className="grid grid-cols-2 gap-4">
//             <select className="h-11 rounded-xl border border-slate-200 px-3 text-sm">
//               <option>Opening Time</option>
//               <option>09:00 AM</option>
//             </select>
//             <select className="h-11 rounded-xl border border-slate-200 px-3 text-sm">
//               <option>Closing Time</option>
//               <option>06:00 PM</option>
//             </select>
//           </div>

//           <select className="mt-4 h-11 w-full rounded-xl border border-slate-200 px-3 text-sm">
//             <option>Working Days</option>
//             <option>Monday - Saturday</option>
//           </select>
//         </Card>

//         <div className="mt-8 flex items-center justify-between">
//           <button
//             onClick={() => (window.location.href = "/step3")}
//             className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm"
//           >
//             ← Back
//           </button>

//           <button
//             onClick={() => (window.location.href = "/step3")}
//             className="rounded-xl bg-purple-500 px-7 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600"
//           >
//             Continue
//           </button>
//         </div>
//       </main>
//     </div>
//   );
// }

// function Card({ title, icon: Icon, children, action }) {
//   return (
//     <div className="mb-5 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
//       <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-3">
//         <div className="flex items-center gap-2">
//           <Icon className="h-4 w-4 text-slate-500" />
//           <h3 className="text-sm font-extrabold text-slate-700">{title}</h3>
//         </div>
//         {action && (
//           <button className="inline-flex items-center gap-1 text-xs font-bold text-purple-600">
//             <Edit3 className="h-3 w-3" /> Edit
//           </button>
//         )}
//       </div>

//       <div className="p-5">{children}</div>
//     </div>
//   );
// }

// function Info({ label, value }) {
//   return (
//     <div>
//       <p className="text-xs font-bold text-slate-400">{label}</p>
//       <p className="mt-1 font-bold text-slate-800">{value}</p>
//     </div>
//   );
// }

// function Label({ children, className = "" }) {
//   return (
//     <label
//       className={`mb-2 block text-xs font-bold text-slate-400 ${className}`}
//     >
//       {children}
//     </label>
//   );
// } 

import React, { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  BookOpen,
  Bot,
  Clock,
  Loader2,
  MessageSquare,
  Plus,
  Save,
  Shield,
  Sparkles,
  X,
} from "lucide-react";
import AgentSteps from "./training/AgentSteps";

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

const defaultStarterQuestions = [
  "Tell me about your services",
  "What products do you offer?",
  "How can I contact your team?",
  "Do you provide pricing details?",
];

function safeArray(value) {
  return Array.isArray(value) && value.length ? value : defaultStarterQuestions;
}

export default function ReviewAgentPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [config, setConfig] = useState(null);

  const [businessName, setBusinessName] = useState("");
  const [industry, setIndustry] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [businessDescription, setBusinessDescription] = useState("");
  const [greetingMessage, setGreetingMessage] = useState("");
  const [starterQuestions, setStarterQuestions] = useState(defaultStarterQuestions);
  const [newQuestion, setNewQuestion] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [restrictionRules, setRestrictionRules] = useState("");
  const [openingTime, setOpeningTime] = useState("09:00 AM");
  const [closingTime, setClosingTime] = useState("06:00 PM");
  const [workingDays, setWorkingDays] = useState("Monday - Saturday");

  const trainingSummary = config?.training_summary || {};
  const knowledgeBase = config?.knowledge_base || {};

  const processedSources = useMemo(() => knowledgeBase.processed_sources || [], [knowledgeBase]);
  const skippedSources = useMemo(() => knowledgeBase.skipped_sources || [], [knowledgeBase]);
  const failedSources = useMemo(() => knowledgeBase.failed_sources || [], [knowledgeBase]);

  useEffect(() => {
    fetchAgentConfig();
  }, []);

  const hydrateForm = (data) => {
    const cfg = data?.config || {};
    setConfig(cfg);

    setBusinessName(cfg.business?.name || cfg.tenant?.tenant_name || "");
    setIndustry(cfg.business?.industry || "General Business");
    setBusinessType(cfg.business?.type || "Business");
    setBusinessDescription(cfg.business?.description || "");
    setGreetingMessage(cfg.chat_experience?.greeting_message || "Welcome! How can I help you today?");
    setStarterQuestions(safeArray(cfg.chat_experience?.starter_questions));
    setSystemPrompt(cfg.behavior?.system_prompt || "");
    setRestrictionRules(cfg.behavior?.restriction_rules || "");
    setOpeningTime(cfg.support_hours?.opening_time || "09:00 AM");
    setClosingTime(cfg.support_hours?.closing_time || "06:00 PM");
    setWorkingDays(cfg.support_hours?.working_days || "Monday - Saturday");
  };

  const fetchAgentConfig = async () => {
    setIsLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("auth_token");
      const response = await fetch(`${API_BASE_URL}/agent-config`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.detail || "Could not load agent configuration.");

      hydrateForm(data);
    } catch (err) {
      setError(err.message || "Could not load agent configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  const saveAgentConfig = async (goNext = false) => {
    setIsSaving(true);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("auth_token");
      const response = await fetch(`${API_BASE_URL}/agent-config`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          business_name: businessName,
          industry,
          business_type: businessType,
          business_description: businessDescription,
          greeting_message: greetingMessage,
          starter_questions: starterQuestions.filter((q) => q.trim()),
          system_prompt: systemPrompt,
          restriction_rules: restrictionRules,
          support_hours: {
            opening_time: openingTime,
            closing_time: closingTime,
            working_days: workingDays,
          },
        }),
      });

      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.detail || "Could not save agent configuration.");

      hydrateForm(data);
      setSuccess(data?.message || "Agent settings saved successfully.");

      if (goNext) {
        window.location.href = "/step3";
      }
    } catch (err) {
      setError(err.message || "Could not save agent configuration.");
    } finally {
      setIsSaving(false);
    }
  };

  const updateStarterQuestion = (index, value) => {
    setStarterQuestions((prev) => prev.map((item, i) => (i === index ? value : item)));
  };

  const removeStarterQuestion = (index) => {
    setStarterQuestions((prev) => prev.filter((_, i) => i !== index));
  };

  const addStarterQuestion = () => {
    const clean = newQuestion.trim();
    if (!clean) return;
    setStarterQuestions((prev) => [...prev, clean].slice(0, 8));
    setNewQuestion("");
  };

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
        <PageHeader />
        <AgentSteps current={4} />
        <div className="flex min-h-[420px] items-center justify-center">
          <div className="inline-flex items-center gap-3 rounded-2xl bg-white px-6 py-4 text-sm font-bold text-slate-600 shadow-sm">
            <Loader2 className="h-5 w-5 animate-spin text-purple-600" /> Loading agent configuration...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-72px)] bg-[#f6f8fc]">
      <PageHeader />
      <AgentSteps current={4} />

      <main className="mx-auto max-w-[720px] px-5 py-7">
        {error && (
          <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
            <AlertCircle className="mt-0.5 h-5 w-5" /> {error}
          </div>
        )}

        {success && (
          <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-bold text-emerald-700">
            {success}
          </div>
        )}

        <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-extrabold text-emerald-700">Agent trained successfully!</p>
              <p className="text-xs font-semibold text-emerald-600">
                Scanned {knowledgeBase.website_documents || 0} pages • Uploaded {knowledgeBase.uploaded_documents || 0} files • Created {knowledgeBase.entries || 0} knowledge entries
              </p>
            </div>
            <button onClick={() => (window.location.href = "/train")} className="text-xs font-bold text-emerald-700">
              Re-scan
            </button>
          </div>
        </div>

        <Card title="Business Info" icon={Bot}>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Name" value={businessName} onChange={setBusinessName} />
            <Field label="Industry" value={industry} onChange={setIndustry} />
            <Field label="Type" value={businessType} onChange={setBusinessType} />
          </div>
        </Card>

        <Card title="Description" icon={BookOpen}>
          <textarea
            value={businessDescription}
            onChange={(e) => setBusinessDescription(e.target.value)}
            className="h-28 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
          />
        </Card>

        <Card title="Knowledge Base" icon={BookOpen}>
          <div className="flex flex-wrap items-center gap-2">
            <Badge>{knowledgeBase.entries || 0} entries</Badge>
            <Badge>{knowledgeBase.website_documents || 0} website pages</Badge>
            <Badge>{knowledgeBase.uploaded_documents || 0} uploaded files</Badge>
            <Badge>{knowledgeBase.total_vectors || 0} total vectors</Badge>
          </div>
        </Card>

        <div className="mb-5 rounded-2xl border border-purple-200 bg-purple-50 p-5">
          <div className="mb-4 flex items-center gap-2 text-purple-700">
            <Sparkles className="h-4 w-4" />
            <h3 className="text-sm font-extrabold">What your AI agent knows</h3>
          </div>

          <div className="text-sm leading-6 text-purple-700">
            <p>Your AI agent “{businessName || config?.tenant?.tenant_name || "your business"}” knows:</p>
            <p>📄 {knowledgeBase.entries || 0} knowledge base entries</p>
            <p>🌐 {knowledgeBase.website_documents || 0} website pages</p>
            <p>📎 {knowledgeBase.uploaded_documents || 0} uploaded documents</p>
            <p>🔍 Your chatbot can answer questions from this trained data.</p>
            {processedSources.length > 0 && <p>✅ Processed sources: {processedSources.slice(0, 3).join(", ")}</p>}
            {skippedSources.length > 0 && <p>⏭ Skipped duplicates: {skippedSources.length}</p>}
            {failedSources.length > 0 && <p>⚠ Failed sources: {failedSources.length}</p>}
          </div>
        </div>

        <Card title="Chat Experience" icon={MessageSquare}>
          <Label>Greeting Message</Label>
          <textarea
            value={greetingMessage}
            onChange={(e) => setGreetingMessage(e.target.value)}
            className="h-20 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
          />

          <Label className="mt-4">Starter Questions</Label>
          {starterQuestions.map((q, index) => (
            <div key={`${q}-${index}`} className="mb-2 flex gap-2">
              <input
                value={q}
                onChange={(e) => updateStarterQuestion(index, e.target.value)}
                className="h-10 flex-1 rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-purple-400"
              />
              <button onClick={() => removeStarterQuestion(index)} className="h-10 w-10 rounded-lg border border-slate-200 text-slate-400 hover:text-red-500">
                ×
              </button>
            </div>
          ))}

          <div className="flex gap-2">
            <input
              value={newQuestion}
              onChange={(e) => setNewQuestion(e.target.value)}
              placeholder="Add question (max 50 chars)..."
              className="h-10 flex-1 rounded-lg border border-dashed border-slate-300 px-3 text-sm outline-none"
            />
            <button onClick={addStarterQuestion} className="h-10 w-10 rounded-lg bg-purple-100 text-purple-600">
              +
            </button>
          </div>
        </Card>

        <Card title="AI Behaviour & Rules" icon={Shield}>
          <Label>System Prompt</Label>
          <textarea
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            className="h-32 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
          />

          <Label className="mt-4">Restriction Rules</Label>
          <textarea
            value={restrictionRules}
            onChange={(e) => setRestrictionRules(e.target.value)}
            className="h-28 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
          />
          <p className="mt-2 text-xs text-slate-400">If this is left empty, backend will automatically save safe default rules.</p>
        </Card>

        <Card title="Support Hours" icon={Clock}>
          <p className="mb-4 text-xs text-slate-400">Set your business hours so the chatbot can tell customers when live support is available.</p>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Opening Time" value={openingTime} onChange={setOpeningTime} />
            <Field label="Closing Time" value={closingTime} onChange={setClosingTime} />
          </div>

          <div className="mt-4">
            <Field label="Working Days" value={workingDays} onChange={setWorkingDays} />
          </div>
        </Card>

        <div className="mt-8 flex items-center justify-between">
          <button onClick={() => (window.location.href = "/step2")} className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 shadow-sm">
            ← Back
          </button>

          <div className="flex gap-3">
            <button onClick={() => saveAgentConfig(false)} disabled={isSaving} className="inline-flex items-center gap-2 rounded-xl border border-purple-200 bg-white px-5 py-3 text-sm font-bold text-purple-600 shadow-sm disabled:opacity-60">
              {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save
            </button>
            <button onClick={() => saveAgentConfig(true)} disabled={isSaving} className="rounded-xl bg-purple-500 px-7 py-3 text-sm font-bold text-white shadow-sm hover:bg-purple-600 disabled:opacity-60">
              Continue
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

function PageHeader() {
  return (
    <div className="border-b border-slate-100 bg-white px-6 py-5 lg:px-8">
      <div className="flex items-center justify-between">
        <button className="inline-flex items-center gap-3 text-[16px] font-bold text-slate-900">
          <Plus className="h-5 w-5 text-purple-600" /> Create New Agent
        </button>

        <div className="flex items-center gap-5">
          <p className="text-xs font-semibold text-slate-400">Step 4 of 5</p>
          <X className="h-4 w-4 text-slate-400" />
        </div>
      </div>
    </div>
  );
}

function Card({ title, icon: Icon, children }) {
  return (
    <div className="mb-5 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-3">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-slate-500" />
          <h3 className="text-sm font-extrabold text-slate-700">{title}</h3>
        </div>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function Field({ label, value, onChange }) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold text-slate-400">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
      />
    </label>
  );
}

function Badge({ children }) {
  return <span className="rounded-full bg-purple-100 px-3 py-1 text-xs font-bold text-purple-600">{children}</span>;
}

function Label({ children, className = "" }) {
  return <label className={`mb-2 block text-xs font-bold text-slate-400 ${className}`}>{children}</label>;
}
